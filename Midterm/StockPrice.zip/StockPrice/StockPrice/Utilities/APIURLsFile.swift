//
//  APIURLsFile.swift
//  StockPrice
//
//  Created by Tejaswi Nemani on 4/10/22.
//

import Foundation

let stockAPIURL = "https://financialmodelingprep.com/api/v3/quote/"
