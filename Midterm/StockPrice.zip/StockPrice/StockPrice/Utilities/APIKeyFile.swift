//
//  APIKeyFile.swift
//  StockPrice
//
//  Created by Tejaswi Nemani on 4/10/22.
//

import Foundation

let apiKey = "5e4a208aa8c2517ce1f8507d50bada53"
